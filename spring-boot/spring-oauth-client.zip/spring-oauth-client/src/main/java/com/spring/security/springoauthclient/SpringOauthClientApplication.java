package com.spring.security.springoauthclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOauthClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOauthClientApplication.class, args);
	}

}
